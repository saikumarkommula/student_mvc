 package com.example.demo.Services;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.models.Project;
@Service
public class ProjectServiceImplementation implements ProjectServices{

	@Override
	public Optional<Project> getProjectById(Long id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Project createProject(Project project) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Project updateProject(Long id, Project project) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProject(Long id) {
		// TODO Auto-generated method stub
		
	}

}
