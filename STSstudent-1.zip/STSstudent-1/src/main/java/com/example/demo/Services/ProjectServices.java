package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import com.example.demo.models.Project;

public interface ProjectServices {

	Optional<Project> getProjectById(Long id);

	static List<Project> getAllProjects() {
		// TODO Auto-generated method stub
		return null;
	}

	Project createProject(Project project);

	Project updateProject(Long id, Project project);

	void deleteProject(Long id);

}
